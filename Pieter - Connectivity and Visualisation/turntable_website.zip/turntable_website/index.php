<!DOCTYPE html>
<html lang="en">

<!-- Website Team Turntable
	
	File: index.php
	Discription: Displays today's highscores, all time highscores and latest gameplays of Turntable Game Technologiecampus Gent
	Table items: *Medal for best 3 players
				 *All time rank
				 *Student/employee number
				 *The player's scores
				 *Time and date of gameplay
	
	Project: KULeuven - Technologiecampus Gent
			 Embedded System Design 2 - Labo

 -->

<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "turntable";
$phpecho = False;

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn && $phpecho) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}
elseif($phpecho){
	echo "Success: A proper connection to MySQL was made!" . PHP_EOL;
	echo "Host information: " . mysqli_get_host_info($conn) . PHP_EOL;
}
?>

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Displays today's highscores, all time highscores and latest gameplays of Turntable Game Technologiecampus Gent">
	<meta name="author" content="Team Turntable">

	<link rel="shortcut icon" href="icons/podium16.png" type="image/x-icon" />
	
	<title>Turntable Highscores</title>

	<!-- Bootstrap core CSS -->
	<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
	<div class="container">
	  <img src="icons/podium32.png"><a class="navbar-brand" href="#" style="padding-left: 14px">Turntable Highscores</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarResponsive">
		<ul class="navbar-nav ml-auto">
		  <li class="nav-item active">
			<a class="nav-link" href="#">Home
			  <span class="sr-only">(current)</span>
			</a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" href="#">Game Rules</a>
		  </li>
		</ul>
	  </div>
	</div>
	</nav>

	<!-- Page Content -->
	<div class="container">
	<div class="row">
	  <div class="col-lg-7 text-center">
		<h1 class="mt-5">Today's Best</h1>
		<p class="lead">Best 3 scores of the day.</p>
		<?php		
		//BEFORE RANK $sql = "SELECT playerId, playerScore, dateTime, @curRank := @curRank + 1 AS rank FROM loradata, (SELECT @curRank := 0) q WHERE CAST(dateTime AS DATE) = CURDATE() ORDER BY playerScore DESC, dateTime ASC LIMIT 3 ";
		$sql = "SELECT subquery.playerId, subquery.playerScore, subquery.dateTime, subquery.rank FROM (SELECT playerId, playerScore, dateTime, @curRank :=@curRank + 1 AS rank FROM loradata, (SELECT @curRank := 0) q ORDER BY playerScore DESC, dateTime ASC) AS subquery WHERE CAST(dateTime AS DATE) = CURDATE() ORDER BY playerScore DESC, dateTime ASC LIMIT 3";
		$result = mysqli_query($conn, $sql);
		$rowcount = 1;
		if (mysqli_num_rows($result) > 0) {
			echo "<table class=\"table table-striped table-bordered\" style=\"border-top:0px;border-bottom:0px;border-left:0px;\"><tr><th style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"></th><th>Rank</th><th>Player</th><th>Score</th><th>Date & Time</th></tr>";
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo"<tr>";
				if ($rowcount == 1){
					echo"<td style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"><img src=\"icons/1.png\"></td>";
				}
				elseif ($rowcount == 2){
					echo"<td style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"><img src=\"icons/2.png\"></td>";
				}
				elseif ($rowcount == 3){
					echo"<td style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"><img src=\"icons/3.png\"></td>";
				}
				else{
					echo"<td style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"></td>";
				}
				echo "<td>".$row["rank"]."</td><td>".$row["playerId"]."</td><td>".$row["playerScore"]."</td><td>".$row["dateTime"]."</td></tr>";
				$rowcount = $rowcount + 1;
			}
			echo "</table>";
		} else {
			echo "There are no attempts yet.";
		}
		?>
		
		<h1 class="mt-5">Hall of Fame</h1>
		<p class="lead">Best 10 scores of all time.</p>
		<?php		
		$sql = "SELECT subquery.playerId, subquery.playerScore, subquery.dateTime, subquery.rank FROM (SELECT playerId, playerScore, dateTime, @curRank :=@curRank + 1 AS rank FROM loradata, (SELECT @curRank := 0) q ORDER BY playerScore DESC, dateTime ASC) AS subquery ORDER BY playerScore DESC, dateTime ASC LIMIT 10";
		//BEFORE RANK $sql = "SELECT playerId, playerScore, dateTime FROM loradata ORDER BY playerScore DESC, dateTime ASC LIMIT 10";
		$result = mysqli_query($conn, $sql);
		if (mysqli_num_rows($result) > 0) {
			echo "<table class=\"table table-striped table-bordered\" style=\"border-top:0px;border-bottom:0px;border-left:0px;\"><tr><th style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"></th><th>Rank</th><th>Player</th><th>Score</th><th>Date & Time</th></tr>";
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo"<tr>";
				if ($row["rank"] == 1){
					echo"<td style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"><img src=\"icons/1.png\"></td>";
				}
				elseif ($row["rank"] == 2){
					echo"<td style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"><img src=\"icons/2.png\"></td>";
				}
				elseif ($row["rank"] == 3){
					echo"<td style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"><img src=\"icons/3.png\"></td>";
				}
				else{
					echo"<td style=\"background-color:#FFFFFF;border-top:0px;border-bottom:0px;border-left:0px;\"></td>";
				}
				echo "<td>".$row["rank"]."</td><td>".$row["playerId"]."</td><td>".$row["playerScore"]."</td><td>".$row["dateTime"]."</td></tr>";
			}
			echo "</table>";
		} else {
			echo "There are no attempts yet.";
		}
		?>
	  </div>

	  <div class="col-lg-5 text-center">
		<h1 class="mt-5">Latest plays</h1>
		<p class="lead">Latest 5 plays.</p>
		<?php		
		$sql = "SELECT subquery.playerId, subquery.playerScore, subquery.dateTime, subquery.rank FROM (SELECT playerId, playerScore, dateTime, @curRank :=@curRank + 1 AS rank FROM loradata, (SELECT @curRank := 0) q ORDER BY playerScore DESC, dateTime ASC) AS subquery ORDER BY dateTime DESC LIMIT 5";
		//BEFORE RANK $sql = "SELECT playerId, playerScore, dateTime, @curRank := @curRank + 1 AS rank FROM loradata, (SELECT @curRank := 0) q ORDER BY dateTime DESC LIMIT 5";
		$result = mysqli_query($conn, $sql);
		if (mysqli_num_rows($result) > 0) {
			echo "<table class=\"table table-striped table-bordered\"><tr><th>Rank</th><th>Player</th><th>Score</th><th>Date & Time</th></tr>";
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<tr><td>".$row["rank"]."</td><td>".$row["playerId"]."</td><td>".$row["playerScore"]."</td><td>".$row["dateTime"]."</td></tr>";
			}
			echo "</table>";
		} else {
			echo "There are no attempts yet.";
		}
		?>
	  </div>
	  
	</div>
	</div>

	<!-- Footer Content -->
	<div class="jumbotron jumbotron-fluid text-center bg-dark text-white" style="margin-bottom:0">
		<div class="container">
		<p>Project Embedded System Design 2 Labo - Team Turntable &#169; 2020</p>
		<div class="text-muted">Icons made by <a class="text-muted" href="https://www.flaticon.com/authors/freepik" title="Freepik">Freepik</a></div>
		</div>
	</div>

	<!-- Bootstrap core JavaScript -->
	<script src="vendor/jquery/jquery.slim.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
<?php
	mysqli_close($conn);
?>