-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 01 mei 2020 om 16:29
-- Serverversie: 5.7.14
-- PHP-versie: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `turntable`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `loradata`
--

CREATE TABLE `loradata` (
  `id` int(11) NOT NULL,
  `device` varchar(36) NOT NULL,
  `playerId` varchar(8) NOT NULL,
  `playerScore` int(11) NOT NULL,
  `dateTime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `loradata`
--

INSERT INTO `loradata` (`id`, `device`, `playerId`, `playerScore`, `dateTime`) VALUES
(1, '8899', 'r0963469', 0, '2020-04-28 13:39:49'),
(2, '8899', 'r0963217', 1, '2020-04-30 08:35:22'),
(3, '8899', 'r0966455', 1, '2020-04-28 13:39:49'),
(4, '8899', 'r0963978', 2, '2020-04-15 14:35:12'),
(5, '8899', 'r0963217', 2, '2020-04-28 13:39:49'),
(6, '8899', 'r0963217', 2, '2020-04-17 10:21:41'),
(7, '8899', 'r0988888', 3, '2020-04-28 13:39:49'),
(8, '8899', 'r3647512', 3, '2020-02-13 23:33:15'),
(9, '8899', 'u0623569', 3, '2020-03-19 09:30:38'),
(10, '8899', 'u0945817', 8, '2020-04-01 11:43:54'),
(34, '8899', 'r1620008', 28, '2020-04-30 15:26:02'),
(33, '8899', 's1026983', 9, '2020-04-30 15:19:49'),
(32, '8899', 'u1234659', 8, '2020-04-30 15:15:15'),
(31, '8899', 'r6497216', 27, '2020-04-30 15:14:12'),
(30, '8899', 'r0584637', 31, '2020-04-30 15:13:10'),
(29, '8899', 'r0963211', 31, '2020-04-15 23:46:31'),
(28, '8899', 'r0963211', 18, '2020-04-15 19:27:17'),
(27, '8899', 'r0963211', 15, '2020-04-13 07:38:31'),
(26, '8899', 'r6397415', 28, '2020-04-28 12:20:20'),
(25, '8899', 's0348896', 12, '2020-04-29 10:37:09'),
(24, '8899', 'r1475268', 8, '2020-04-29 16:43:26'),
(23, '8899', 'r0486239', 10, '2020-04-29 11:43:54'),
(45, '8899', 'r0114772', 22, '2020-04-30 17:28:55'),
(36, '8899', 'r0036927', 24, '2020-04-30 15:38:07'),
(37, '8899', 'r0547553', 12, '2020-04-30 15:41:09'),
(53, '8899', 'r0697361', 5, '2020-05-01 10:38:46'),
(39, '8899', 'r0298876', 33, '2020-04-30 15:47:43'),
(40, '8899', 'r0459963', 28, '2020-04-30 15:50:56'),
(41, '8899', 'r0124475', 32, '2020-04-30 15:59:36'),
(42, '8899', 'r0021159', 8, '2020-04-30 16:06:02'),
(43, '8899', 'r0023578', 6, '2020-04-30 16:09:20'),
(44, '8899', 'r0559666', 14, '2020-04-30 17:19:30'),
(52, '8899', 'r0237784', 19, '2020-05-01 10:22:51'),
(51, '8899', 'r0158963', 26, '2020-05-01 09:18:22'),
(50, '8899', 'r0158963', 7, '2020-05-01 09:12:43');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `loradata`
--
ALTER TABLE `loradata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `loradata`
--
ALTER TABLE `loradata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
